# Real-time-Chat-with-Authentication
Real-time chat App using JS React and Firebase
